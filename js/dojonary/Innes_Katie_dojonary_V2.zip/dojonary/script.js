console.log ("Connected")

function giveAlert () {
    alert("Ninja was liked");
}
function changeText(element){
    element.innerText="Logout";
}

function hide(element) {
    element.remove();
}