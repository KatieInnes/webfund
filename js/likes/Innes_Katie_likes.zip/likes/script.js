console.log ("Connected")

var likesOne = document.querySelector("span#one")
var likesTwo = document.querySelector("span#two")
var likesThree = document.querySelector("span#three")

function increaseLikesOne() {
    likesOne.innerText++;
}

function increaseLikesTwo() {
    likesTwo.innerText++;
}

function increaseLikesThree() {
    likesThree.innerText++;
}
